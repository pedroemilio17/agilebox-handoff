# design/kan · referência do Kan (assistente guiado + mascote 3D)

Referência visual e de assets. **Não é código para reaproveitar** (mesma regra do `design/*.dc.html`).

- `assets/agilebox_mascote.glb` — modelo final (≈166 KB; 3 clips: `Open` 1,208 s, `Idle_Float` 2,0 s em loop, `Spin_360` 1,042 s). Já corrigido: pesos de morph amostrados por frame.
- `assets/agilebox_mascote.blend` — fonte editável (Blender 5.x).
- `assets/kan_fechado.png`, `kan_aberto.png` — pôsteres (fallback sem WebGL / reduced-motion).
- `assets/eyes_*_extremo.png` — limites do movimento dos olhos, medidos no Blender.
- `canvas/` — telas do canvas de design: `Main` (protótipo do chat), `Painel_Fechado`, `Painel_Aberto`, `Estados`, `Roteiro`, `Mascote3D`. Formato `.dc.html`: leia CSS/markup, não execute.
- `src/kan3d.reference.js` — protótipo three.js (montagem, clips, tween de material, olhos, pausa fora da tela). Referência de lógica; reescrever em TS/React.
- `tools/build_mascote_anim.py` — gera o `.blend`/GLB (Blender headless). `fix_glb_morphs.py` — reamostra os pesos de morph no GLB.

Contrato do modelo (nós, clips, limites dos olhos, tabela de tween de material): ver `docs/KAN.md` §4.
