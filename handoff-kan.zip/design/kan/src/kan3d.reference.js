// Kan 3D: three.js + o GLB embutido (sem fetch), para o canvas de design.
import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import GLB_B64 from './glb-data.js';

function glbBuffer() {
  const bin = atob(GLB_B64);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out.buffer;
}

// tween de material (o glTF não anima material): frames do Open já deslocados p/ t=0, 24 fps
const MAT_TWEENS = {
  MAT_AgileBox_Esquerda: { t0: 7 / 24, t1: 25 / 24, from: [0x1d1c23, 0.58, 1.0], to: [0x17161c, 0.28, 0.78] },
  MAT_AgileBox_Direita: { t0: 9 / 24, t1: 27 / 24, from: [0x1d1c23, 0.58, 1.0], to: [0xc8f03c, 0.42, 1.0] },
};
const clamp01 = (x) => Math.max(0, Math.min(1, x));
const smooth = (x) => x * x * (3 - 2 * x);

function mount(container, opts = {}) {
  const o = Object.assign({ orbit: true, view: 'full', follow: true, fps: 30 }, opts);
  const w = () => container.clientWidth || 300;
  const h = () => container.clientHeight || 300;

  const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5));
  renderer.setSize(w(), h());
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.1;
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.domElement.style.cssText = 'display:block;width:100%;height:100%;outline:none';
  container.appendChild(renderer.domElement);

  const scene = new THREE.Scene();
  const pmrem = new THREE.PMREMGenerator(renderer);
  scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
  const key = new THREE.DirectionalLight(0xffffff, 1.2); key.position.set(-4, 5, 6); scene.add(key);
  const rim = new THREE.DirectionalLight(0xd6cfff, 0.8); rim.position.set(5, 3, -5); scene.add(rim);

  const camera = new THREE.PerspectiveCamera(o.view === 'closed' ? 26 : 30, w() / h(), 0.1, 100);
  const target = new THREE.Vector3(0, o.view === 'closed' ? 0.1 : 0.05, 0);
  const dist = o.view === 'closed' ? 6.8 : 10.5;
  camera.position.set(dist * 0.34, dist * 0.2 + target.y, dist * 0.92);
  camera.lookAt(target);

  let controls = null;
  if (o.orbit) {
    controls = new OrbitControls(camera, renderer.domElement);
    controls.target.copy(target);
    controls.enableZoom = false; controls.enablePan = false; controls.enableDamping = true;
    controls.minPolarAngle = Math.PI * 0.25; controls.maxPolarAngle = Math.PI * 0.62;
  }

  const api = { ready: false, current: 'Idle_Float', openness: 0, _fin: [] };
  let mixer, actions = {}, eyes, mats = {}, raf = 0, last = 0, visible = true, alive = true;
  const look = new THREE.Vector2(0, 0), lookT = new THREE.Vector2(0, 0);

  new GLTFLoader().parse(glbBuffer(), '', (gltf) => {
    if (!alive) return;
    scene.add(gltf.scene);
    gltf.scene.traverse((n) => {
      if (n.name === 'Olhos_LED') eyes = n;
      if (n.isMesh) {
        const m = n.material;
        if (MAT_TWEENS[m.name]) { m.transparent = m.name === 'MAT_AgileBox_Esquerda'; mats[m.name] = m; }
        if (m.name === 'MAT_AgileBox_LED') { m.emissive = new THREE.Color(0xf2f0f6); m.emissiveIntensity = 2.4; }
      }
    });
    mixer = new THREE.AnimationMixer(gltf.scene);
    gltf.animations.forEach((c) => { actions[c.name] = mixer.clipAction(c); });
    ['Spin_360', 'Open'].forEach((n) => { const a = actions[n]; if (a) { a.setLoop(THREE.LoopOnce, 1); a.clampWhenFinished = true; } });
    if (actions.Idle_Float) actions.Idle_Float.play();
    mixer.addEventListener('finished', (e) => {
      const name = e.action.getClip().name;
      if (name === 'Spin_360') { e.action.stop(); }
      api._fin.forEach((cb) => cb(name, e.action.timeScale < 0));
    });
    api.ready = true;
    if (o.clip) api.play(o.clip);
    if (o.onReady) o.onReady(api);
  }, (err) => { container.setAttribute('data-kan3d-error', String(err && err.message || err)); });

  api.play = function (name, p = {}) {
    if (!api.ready) { o.clip = name; return; }
    if (name === 'Idle_Float') { api.current = name; return; }
    const a = actions[name]; if (!a) return;
    api.current = p.reverse ? name + ' (reverso)' : name;
    a.enabled = true; a.paused = false;
    if (p.reverse) { a.timeScale = -1; if (!a.isRunning() && a.time === 0) a.time = a.getClip().duration; a.play(); }
    else { a.reset(); a.timeScale = 1; a.play(); }
  };
  api.onFinished = (cb) => api._fin.push(cb);
  api.setOpen = function (v) { // pula direto para fechado/aberto
    const a = actions.Open; if (!a) return;
    a.reset(); a.play(); a.paused = true; a.time = v ? a.getClip().duration : 0;
  };

  function applyMaterials() {
    const a = actions.Open; const t = a && a.enabled ? a.time : 0;
    api.openness = a ? clamp01(t / a.getClip().duration) : 0;
    for (const k in mats) {
      const tw = MAT_TWEENS[k], m = mats[k];
      const p = smooth(clamp01((t - tw.t0) / (tw.t1 - tw.t0)));
      m.color.setHex(tw.from[0]).lerp(new THREE.Color(tw.to[0]), p);
      m.roughness = tw.from[1] + (tw.to[1] - tw.from[1]) * p;
      m.opacity = tw.from[2] + (tw.to[2] - tw.from[2]) * p;
    }
  }

  function applyEyes(dt) {
    if (!eyes) return;
    look.lerp(lookT, 1 - Math.exp(-dt * 8));
    const op = api.openness;
    const rx = 0.05 + (0.33 - 0.05) * op;            // limites medidos no Blender
    const zUp = 0.25 + (0.035 - 0.25) * op, zDn = 0.30 + (0.035 - 0.30) * op;
    eyes.position.x = look.x * rx;
    eyes.position.y = look.y > 0 ? look.y * zUp : look.y * zDn; // Z do Blender = Y no glTF
  }

  function onMove(e) {
    if (!o.follow) return;
    const r = container.getBoundingClientRect();
    lookT.set(clamp01((e.clientX - r.left) / r.width) * 2 - 1, -(clamp01((e.clientY - r.top) / r.height) * 2 - 1));
  }
  function onLeave() { lookT.set(0, 0); }
  window.addEventListener('pointermove', onMove);
  container.addEventListener('pointerleave', onLeave);

  const io = 'IntersectionObserver' in window ? new IntersectionObserver((es) => { visible = es[0].isIntersecting; }) : null;
  if (io) io.observe(container);
  const ro = 'ResizeObserver' in window ? new ResizeObserver(() => { renderer.setSize(w(), h()); camera.aspect = w() / h(); camera.updateProjectionMatrix(); }) : null;
  if (ro) ro.observe(container);

  const clock = new THREE.Clock();
  function tick(now) {
    raf = requestAnimationFrame(tick);
    if (!visible || document.hidden) { clock.getDelta(); return; }
    if (now - last < 1000 / o.fps - 1) return;
    last = now;
    const dt = Math.min(clock.getDelta(), 0.1);
    if (mixer) mixer.update(dt);
    applyMaterials(); applyEyes(dt);
    if (controls) controls.update();
    renderer.render(scene, camera);
  }
  raf = requestAnimationFrame(tick);

  api.dispose = function () {
    alive = false; cancelAnimationFrame(raf);
    window.removeEventListener('pointermove', onMove);
    container.removeEventListener('pointerleave', onLeave);
    if (io) io.disconnect(); if (ro) ro.disconnect();
    if (controls) controls.dispose();
    renderer.dispose(); pmrem.dispose();
    if (renderer.domElement.parentNode) renderer.domElement.parentNode.removeChild(renderer.domElement);
  };
  return api;
}

window.KAN3D = { mount };
