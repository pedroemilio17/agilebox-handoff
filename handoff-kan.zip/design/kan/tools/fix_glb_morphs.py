import bpy, json, struct
bpy.ops.wm.open_mainfile(filepath='/home/claude/out/agilebox_mascote_anim.blend')
s=bpy.context.scene
names=['Bloco_Centro','Bloco_Direita','Bloco_Esquerda']
samples={n:[] for n in names}
for f in range(1,31):
    s.frame_set(f)
    dg=bpy.context.evaluated_depsgraph_get()
    for n in names:
        kb=bpy.data.objects[n].data.shape_keys.key_blocks
        samples[n].append([kb[k].value for k in range(1,len(kb))])
src='/home/claude/out/agilebox_mascote.glb'
d=open(src,'rb').read()
jl=struct.unpack('<I',d[12:16])[0]; g=json.loads(d[20:20+jl])
o=20+jl; bl=struct.unpack('<I',d[o:o+4])[0]; buf=bytearray(d[o+8:o+8+bl])
node_idx={nd['name']:i for i,nd in enumerate(g['nodes'])}
def add(data, fmt, count, typ, mn=None, mx=None):
    while len(buf)%4: buf.append(0)
    off=len(buf); buf.extend(struct.pack('<'+fmt*len(data),*data))
    g['bufferViews'].append({'buffer':0,'byteOffset':off,'byteLength':len(data)*4})
    acc={'bufferView':len(g['bufferViews'])-1,'componentType':5126,'count':count,'type':typ}
    if mn is not None: acc['min']=mn; acc['max']=mx
    g['accessors'].append(acc); return len(g['accessors'])-1
times=[(f-1)/24 for f in range(1,31)]
tin=add(times,'f',30,'SCALAR',[times[0]],[times[-1]])
an=[a for a in g['animations'] if a['name']=='Open'][0]
fixed=[]
for ch in an['channels']:
    if ch['target']['path']=='weights':
        nm=g['nodes'][ch['target']['node']]['name']
        flat=[v for row in samples[nm] for v in row]
        out=add(flat,'f',len(flat),'SCALAR')
        an['samplers'][ch['sampler']]={'input':tin,'output':out,'interpolation':'LINEAR'}
        fixed.append((nm,[round(x,2) for x in samples[nm][0]],[round(x,2) for x in samples[nm][14]],[round(x,2) for x in samples[nm][-1]]))
g['buffers'][0]['byteLength']=len(buf)
while len(buf)%4: buf.append(0)
js=json.dumps(g,separators=(',',':')).encode()
while len(js)%4: js+=b' '
out=struct.pack('<III',0x46546C67,2,12+8+len(js)+8+len(buf))+struct.pack('<II',len(js),0x4E4F534A)+js+struct.pack('<II',len(buf),0x004E4942)+bytes(buf)
open(src,'wb').write(out)
print('FIXED',fixed)
