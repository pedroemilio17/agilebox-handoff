"""AgileBox - mascote assistente: 3 squircles, Frame 1 (fechado) -> Frame 30 (chat aberto).
Blender 5.x | Z up | frente = -Y | unidades em metros.
Dimensoes animadas por shape keys relativas por eixo (Dim_X/Dim_Y/Dim_Z), assim o raio do bevel
nunca e distorcido por escala nao uniforme.
"""
import bpy, bmesh, math, os, sys, json
from mathutils import Vector
from mathutils.bvhtree import BVHTree

OUT = os.environ.get("OUT_DIR", "/home/claude/out")
os.makedirs(OUT, exist_ok=True)

# ---------------------------------------------------------------- timeline (frames)
T = dict(
    c_rise=(1, 14), c_wide=(10, 20),
    l_rot=(8, 20), l_dim=(14, 26), l_x=(10, 30), l_z=(8, 30), l_y=(8, 14, 22), l_mat=(8, 26),
    l_rec=(24, 30),
    r_z=(3, 17), r_x=(20, 30), r_rot=(4, 17), r_mat=(10, 28), r_chk=(24, 30),
)
if os.environ.get("TIMELINE"):
    T.update({k: tuple(v) for k, v in json.loads(os.environ["TIMELINE"]).items()})

SEG, PROF = 5, 0.6   # 5 segmentos; perfil levemente "squircle"


def lin(hexstr):
    h = hexstr.lstrip("#")
    c = [int(h[i:i + 2], 16) / 255 for i in (0, 2, 4)]
    return [(v / 12.92 if v <= 0.04045 else ((v + 0.055) / 1.055) ** 2.4) for v in c] + [1.0]


bpy.ops.wm.read_factory_settings(use_empty=True)
scene = bpy.context.scene
scene.frame_start, scene.frame_end = 1, 30
scene.unit_settings.system = "METRIC"
coll = bpy.data.collections.new("Mascote")
scene.collection.children.link(coll)


# ---------------------------------------------------------------- geometry
def variant(dims, r, depth=0.0, inset=None):
    bm = bmesh.new()
    bmesh.ops.create_cube(bm, size=1.0)
    for v in bm.verts:
        v.co = Vector((v.co.x * dims[0], v.co.y * dims[1], v.co.z * dims[2]))
    bmesh.ops.bevel(bm, geom=list(bm.edges), offset=r, offset_type="OFFSET", segments=SEG,
                    profile=PROF, affect="EDGES", clamp_overlap=False)
    bm.normal_update()
    floor = None
    if inset:
        front = [f for f in bm.faces if f.normal.y < -0.999]
        assert len(front) == 1, len(front)
        bmesh.ops.inset_region(bm, faces=front, thickness=inset, depth=0.0, use_even_offset=True)
        ex = bmesh.ops.extrude_discrete_faces(bm, faces=front)
        floor = ex["faces"][0]
        for v in floor.verts:
            v.co.y += depth
    bm.normal_update()
    return bm, floor


def coords(*a, **k):
    bm, _ = variant(*a, **k)
    c = [v.co.copy() for v in bm.verts]
    bm.free()
    return c


def build_block(name, dimsA, dimsB, r, loc, recess=None, inset=0.08):
    """recess=None ou profundidade (m) do rebaixo frontal."""
    bm, floor = variant(dimsA, r, 0.0, inset if recess else None)
    floor_idx = None
    if floor is not None:
        for e in floor.edges:
            for f in e.link_faces:
                if f != floor:
                    for e2 in f.edges:
                        e2.smooth = False
            e.smooth = False
        bm.faces.index_update()
        floor_idx = floor.index
    for f in bm.faces:
        f.smooth = True
    base = [v.co.copy() for v in bm.verts]
    mesh = bpy.data.meshes.new(name + "_mesh")
    bm.to_mesh(mesh)
    bm.free()
    ob = bpy.data.objects.new(name, mesh)
    coll.objects.link(ob)
    ob.location = loc
    ob.shape_key_add(name="Basis", from_mix=False)
    ins = inset if recess else None
    keys = {
        "Dim_X": coords((dimsB[0], dimsA[1], dimsA[2]), r, 0.0, ins),
        "Dim_Y": coords((dimsA[0], dimsB[1], dimsA[2]), r, 0.0, ins),
        "Dim_Z": coords((dimsA[0], dimsA[1], dimsB[2]), r, 0.0, ins),
    }
    if recess:
        keys["Recesso"] = coords(dimsA, r, recess, ins)
    for kname, cs in keys.items():
        assert len(cs) == len(base), (name, kname)
        for b, c in zip(base, cs):   # mesma topologia/ordem: sinais relativos ao centro iguais
            for ax in range(3):
                assert abs(b[ax]) < 1e-5 or abs(c[ax]) < 1e-5 or (b[ax] > 0) == (c[ax] > 0), (name, kname)
        k = ob.shape_key_add(name=kname, from_mix=False)
        for i, c in enumerate(cs):
            k.data[i].co = c
        k.value = 0.0
    mod = ob.modifiers.new("Normais_Ponderadas", "WEIGHTED_NORMAL")
    mod.mode, mod.keep_sharp, mod.weight = "FACE_AREA", True, 50
    return ob, floor_idx


def set_uv_chat(ob, floor_idx, finalB_world_rotY=-90):
    """UV 0-1 no piso do rebaixo, ja orientada para o painel final (rot Y = -90deg):
    u cresce com +X do mundo (= -Z local), v cresce com +Z do mundo (= +X local)."""
    key = ob.data.shape_keys
    fin = []
    for i, v in enumerate(ob.data.vertices):
        p = Vector(v.co)
        for kb in key.key_blocks[1:]:
            p += (kb.data[i].co - key.key_blocks[0].data[i].co)
        fin.append(p)
    poly = ob.data.polygons[floor_idx]
    xs = [fin[i].x for i in poly.vertices]
    zs = [fin[i].z for i in poly.vertices]
    x0, x1, z0, z1 = min(xs), max(xs), min(zs), max(zs)
    uv = ob.data.uv_layers.new(name="UV_Chat")
    for li in poly.loop_indices:
        vi = ob.data.loops[li].vertex_index
        uv.data[li].uv = ((z1 - fin[vi].z) / (z1 - z0), (fin[vi].x - x0) / (x1 - x0))
    return (x1 - x0, z1 - z0)


# ---------------------------------------------------------------- materials
def principled(name, color, rough, trans=0.0):
    m = bpy.data.materials.new(name)
    m.use_nodes = True
    b = m.node_tree.nodes["Principled BSDF"]
    b.inputs["Base Color"].default_value = lin(color)
    b.inputs["Roughness"].default_value = rough
    b.inputs["Transmission Weight"].default_value = trans
    return m, b


mat_c, bsdf_c = principled("MAT_AgileBox_Centro", "#26252d", 0.48)
mat_l, bsdf_l = principled("MAT_AgileBox_Esquerda", "#1d1c23", 0.58)
mat_r, bsdf_r = principled("MAT_AgileBox_Direita", "#1d1c23", 0.58)
mat_chk, _ = principled("MAT_AgileBox_Check", "#111015", 0.5)

mat_eye = bpy.data.materials.new("MAT_AgileBox_LED")
mat_eye.use_nodes = True
nt = mat_eye.node_tree
nt.nodes.clear()
em = nt.nodes.new("ShaderNodeEmission")
em.inputs["Color"].default_value = lin("#f2f0f6")
em.inputs["Strength"].default_value = 2.4
out = nt.nodes.new("ShaderNodeOutputMaterial")
nt.links.new(em.outputs["Emission"], out.inputs["Surface"])

# ---------------------------------------------------------------- objects
centro, _ = build_block("Bloco_Centro", (1.0, 0.8, 2.2), (1.6, 0.7, 0.65), 0.22, (0, 0, 0))
esq, esq_floor = build_block("Bloco_Esquerda", (0.65, 0.7, 1.65), (2.0, 0.45, 3.4), 0.18,
                             (-1.05, 0, -0.15), recess=0.015)
dire, _ = build_block("Bloco_Direita", (0.65, 0.7, 1.65), (0.55, 0.6, 1.1), 0.18, (1.05, 0, -0.15))
ui_size = set_uv_chat(esq, esq_floor)
centro.data.materials.append(mat_c)
esq.data.materials.append(mat_l)
dire.data.materials.append(mat_r)

# ---- hierarquia: Root (posicao no app) > Float (idle) > Spin (360) > blocos
def empty(name, parent=None, size=0.25):
    e = bpy.data.objects.new(name, None)
    e.empty_display_type = "PLAIN_AXES"
    e.empty_display_size = size
    coll.objects.link(e)
    e.parent = parent
    return e


root = empty("Mascote_Root")
flt = empty("Mascote_Float", root)
spn = empty("Mascote_Spin", flt)
for _ob in (centro, esq, dire):
    _ob.parent = spn
anchor = empty("Olhos_Ancora", centro, 0.1)   # animado pelo clipe Open

# Olhos_LED: 2 discos planos (r=0.06, espacamento 0.32), levemente embutidos (0.006 salientes)
bm = bmesh.new()
for sx in (-0.16, 0.16):
    bmesh.ops.create_cone(bm, cap_ends=True, segments=48, radius1=0.06, radius2=0.06, depth=0.02,
                          matrix=__import__("mathutils").Matrix.Translation((sx, 0, 0)) @
                          __import__("mathutils").Matrix.Rotation(math.pi / 2, 4, "X"))
eye_mesh = bpy.data.meshes.new("Olhos_LED_mesh")
bm.to_mesh(eye_mesh)
bm.free()
eyes = bpy.data.objects.new("Olhos_LED", eye_mesh)
coll.objects.link(eyes)
eyes.parent = anchor   # Olhos_LED fica livre para o app deslocar (olhar)
EYE_Y0, EYE_Y1 = -0.4 + 0.004, -0.35 + 0.004   # face frontal -0.40 (fechado) / -0.35 (aberto)
anchor.location = (0, EYE_Y0, 0.55)
eye_mesh.materials.append(mat_eye)

# Icone checkmark (preto-violeta) na face frontal -Y do botao
bm = bmesh.new()
pts = [(-0.50, 0.02), (-0.36, 0.16), (-0.14, -0.06), (0.36, 0.44), (0.50, 0.30), (-0.14, -0.34)]
S = 0.30
vs = [bm.verts.new((x * S, 0, (y - 0.05) * S)) for x, y in pts]
face = bm.faces.new(vs)
bm.normal_update()
if face.normal.y > 0:
    face.normal_flip()
res = bmesh.ops.extrude_face_region(bm, geom=[face])
bmesh.ops.translate(bm, verts=[g for g in res["geom"] if isinstance(g, bmesh.types.BMVert)], vec=(0, -0.02, 0))
bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
chk_mesh = bpy.data.meshes.new("Icone_Check_mesh")
bm.to_mesh(chk_mesh)
bm.free()
chk = bpy.data.objects.new("Icone_Check", chk_mesh)
coll.objects.link(chk)
chk.parent = dire
chk_mesh.materials.append(mat_chk)
bev = chk.modifiers.new("Bevel", "BEVEL")
bev.width, bev.segments, bev.limit_method = 0.008, 2, "ANGLE"
CHK_Y0, CHK_Y1 = -0.35 + 0.008, -0.30 + 0.008
chk.location = (0, CHK_Y1, 0)
chk.rotation_euler = (0, -math.pi / 2, 0)   # compensa +90deg do pai -> upright no Frame 30
chk.scale = (0.001,) * 3


# ---------------------------------------------------------------- animation
def key_obj(ob, prop, idx, pairs):
    for f, v in pairs:
        if idx is None:
            setattr(ob, prop, v)
        else:
            getattr(ob, prop)[idx] = v
        ob.keyframe_insert(prop, index=-1 if idx is None else idx, frame=f)


def key_sk(ob, name, f0, f1):
    kb = ob.data.shape_keys.key_blocks[name]
    for f, v in ((f0, 0.0), (f1, 1.0)):
        kb.value = v
        kb.keyframe_insert("value", frame=f)


def key_sock(sock, f0, v0, f1, v1):
    for f, v in ((f0, v0), (f1, v1)):
        sock.default_value = v
        sock.keyframe_insert("default_value", frame=f)


# Centro
a, b = T["c_rise"]
key_obj(centro, "location", 2, [(a, 0.0), (b, 1.55)])
key_sk(centro, "Dim_Z", a, b)
key_sk(centro, "Dim_Y", a, b)
key_sk(centro, "Dim_X", *T["c_wide"])
key_obj(anchor, "location", 2, [(a, 0.55), (b, 0.0)])
key_obj(anchor, "location", 1, [(a, EYE_Y0), (b, EYE_Y1)])

# Esquerda -> painel de chat (vidro fosco)
a, b = T["l_rot"]
key_obj(esq, "rotation_euler", 1, [(a, 0.0), (b, -math.pi / 2)])
for k in ("Dim_X", "Dim_Y", "Dim_Z"):
    key_sk(esq, k, *T["l_dim"])
key_sk(esq, "Recesso", *T["l_rec"])
key_obj(esq, "location", 0, [(T["l_x"][0], -1.05), (T["l_x"][1], 0.0)])
key_obj(esq, "location", 2, [(T["l_z"][0], -0.15), (T["l_z"][1], 0.0)])
y0, ym, y1 = T["l_y"]
key_obj(esq, "location", 1, [(y0, 0.0), (ym, 0.3), (y1, 0.0)])
m0, m1 = T["l_mat"]
key_sock(bsdf_l.inputs["Base Color"], m0, lin("#1d1c23"), m1, lin("#17161c"))
key_sock(bsdf_l.inputs["Roughness"], m0, 0.58, m1, 0.28)
key_sock(bsdf_l.inputs["Transmission Weight"], m0, 0.0, m1, 0.72)

# Direita -> botao verde-lima com check
a, b = T["r_rot"]
key_obj(dire, "rotation_euler", 1, [(a, 0.0), (b, math.pi / 2)])
for k in ("Dim_X", "Dim_Y", "Dim_Z"):
    key_sk(dire, k, a, b)
key_obj(dire, "location", 2, [(T["r_z"][0], -0.15), (T["r_z"][1], -1.55)])
key_obj(dire, "location", 0, [(T["r_x"][0], 1.05), (T["r_x"][1], 0.0)])
m0, m1 = T["r_mat"]
key_sock(bsdf_r.inputs["Base Color"], m0, lin("#1d1c23"), m1, lin("#c8f03c"))
key_sock(bsdf_r.inputs["Roughness"], m0, 0.58, m1, 0.42)
key_obj(chk, "scale", None, [(T["r_chk"][0], (0.001,) * 3), (T["r_chk"][1], (1.0,) * 3)])
key_obj(chk, "location", 1, [(a, CHK_Y0), (b, CHK_Y1)])

scene.timeline_markers.new("Fechado", frame=1)
scene.timeline_markers.new("Aberto", frame=30)

# ---------------------------------------------------------------- world, camera, lights
w = bpy.data.worlds.new("Mundo_Dark")
scene.world = w
w.use_nodes = True
bg = w.node_tree.nodes["Background"]
bg.inputs["Color"].default_value = lin("#0d0d11")
bg.inputs["Strength"].default_value = 1.0

target = bpy.data.objects.new("Alvo_Camera", None)
coll.objects.link(target)
target.location = (0, 0, 0.05)


def track(ob):
    c = ob.constraints.new("TRACK_TO")
    c.target, c.track_axis, c.up_axis = target, "TRACK_NEGATIVE_Z", "UP_Y"


def add_cam(name, loc, lens):
    cd = bpy.data.cameras.new(name)
    cd.lens = lens
    co = bpy.data.objects.new(name, cd)
    coll.objects.link(co)
    co.location = loc
    track(co)
    return co


cam34 = add_cam("Cam_3-4", (4.2, -11.5, 3.0), 62)
camf = add_cam("Cam_Frente", (0, -13, 0.05), 62)
scene.camera = cam34


def add_light(name, loc, energy, size):
    ld = bpy.data.lights.new(name, "AREA")
    ld.energy, ld.size = energy, size
    lo = bpy.data.objects.new(name, ld)
    coll.objects.link(lo)
    lo.location = loc
    track(lo)


add_light("Luz_Key", (-4.5, -6.5, 5.0), 900, 3.5)
add_light("Luz_Rim", (5.0, 4.5, 3.5), 600, 3.0)
add_light("Luz_Fill", (5.5, -6.0, 0.8), 260, 4.0)
add_light("Luz_Rim2", (-5.0, 4.0, 2.5), 350, 3.0)

r = scene.render
r.engine = "CYCLES"
scene.cycles.device = "CPU"
scene.cycles.samples = 48
scene.cycles.use_denoising = True
r.resolution_x, r.resolution_y, r.resolution_percentage = 1280, 720, 100
r.image_settings.file_format = "PNG"

# ---------------------------------------------------------------- verification
def eval_world_verts(ob, dg):
    ev = ob.evaluated_get(dg)
    me = ev.to_mesh()
    mw = ev.matrix_world
    vs = [mw @ v.co for v in me.vertices]
    ev.to_mesh_clear()
    return vs


def bbox(vs):
    mn = [min(v[i] for v in vs) for i in range(3)]
    mx = [max(v[i] for v in vs) for i in range(3)]
    return mn, mx


def world_bvh(ob, dg):
    ev = ob.evaluated_get(dg)
    me = ev.to_mesh()
    me.calc_loop_triangles()
    mw = ev.matrix_world
    vs = [mw @ v.co for v in me.vertices]
    tr = [tuple(t.vertices) for t in me.loop_triangles]
    b = BVHTree.FromPolygons(vs, tr, all_triangles=True)
    ev.to_mesh_clear()
    return b


report = {"ui_floor_size_m_local": [round(x, 4) for x in ui_size], "dims": {}, "overlaps": []}
for f in (1, 30):
    scene.frame_set(f)
    dg = bpy.context.evaluated_depsgraph_get()
    d = {}
    for ob in (centro, esq, dire):
        mn, mx = bbox(eval_world_verts(ob, dg))
        d[ob.name] = {"dim": [round(mx[i] - mn[i], 4) for i in range(3)],
                      "center": [round((mx[i] + mn[i]) / 2, 4) for i in range(3)]}
    report["dims"][f] = d

blocks = [centro, esq, dire]
extras = {eyes: centro, chk: dire}
steps = 4
for f in range(1, 31):
    for s in range(steps):
        if f == 30 and s > 0:
            break
        scene.frame_set(f, subframe=s / steps)
        dg = bpy.context.evaluated_depsgraph_get()
        bv = {ob: world_bvh(ob, dg) for ob in blocks + list(extras)}
        objs = blocks + list(extras)
        for i in range(len(objs)):
            for j in range(i + 1, len(objs)):
                A, B = objs[i], objs[j]
                if extras.get(A) is B or extras.get(B) is A:
                    continue
                if bv[A].overlap(bv[B]):
                    report["overlaps"].append((round(f + s / steps, 2), A.name, B.name))

# orientacao UV no frame 30
scene.frame_set(30)
dg = bpy.context.evaluated_depsgraph_get()
ev = esq.evaluated_get(dg)
me = ev.to_mesh()
poly = me.polygons[esq_floor]
uvl = me.uv_layers["UV_Chat"]
mw = ev.matrix_world
pts = []
for li in poly.loop_indices:
    wv = mw @ me.vertices[me.loops[li].vertex_index].co
    pts.append((round(wv.x, 3), round(wv.y, 3), round(wv.z, 3), tuple(round(c, 3) for c in uvl.data[li].uv)))
report["uv_floor_world_vs_uv"] = pts
ev.to_mesh_clear()

report["overlap_count"] = len(report["overlaps"])
report["overlaps"] = report["overlaps"][:40]
print("REPORT", json.dumps(report, indent=1))


# =====================================================================================
# v2: contrato do modelo, clipes (Open / Idle_Float / Spin_360), NLA, testes e GLB
# =====================================================================================
import struct
FPS = 24
scene.render.fps = FPS


def fcurves_of(idb):
    out = []
    act = idb.animation_data.action
    for layer in act.layers:
        for strip in layer.strips:
            for cb in strip.channelbags:
                out += list(cb.fcurves)
    return out


# ---- extras lidos pelo app (viram "extras" no GLB)
eyes["agb_role"] = "look_offset"       # o app desloca ESTE no local x/z para os olhos "olharem"
eyes["look_range_closed"] = {"x": [-0.05, 0.05], "z": [-0.30, 0.25]}
eyes["look_range_open"] = {"x": [-0.33, 0.33], "z": [-0.035, 0.035]}
esq["agb_material"] = {"from": {"color": "#1d1c23", "roughness": 0.58, "transmission": 0.0},
                       "to": {"color": "#17161c", "roughness": 0.28, "transmission": 0.72},
                       "frames": list(T["l_mat"])}
dire["agb_material"] = {"from": {"color": "#1d1c23", "roughness": 0.58},
                        "to": {"color": "#c8f03c", "roughness": 0.42},
                        "frames": list(T["r_mat"])}
esq["agb_ui_uv"] = "UV_Chat (0-1) no piso do rebaixo; proporcao 1.48:2.88 (local)"
root["agb_clips"] = {"fps": FPS, "Open": [1, 30], "Idle_Float": [1, 49], "Spin_360": [1, 26]}


# ---- teste dos limites dos olhos (raycast: o disco precisa ficar sobre a face plana)
def eye_range_test(frame, rng):
    scene.frame_set(frame)
    worst = 0.0
    for x in rng["x"]:
        for z in rng["z"]:
            eyes.location = (x, 0, z)
            bpy.context.view_layer.update()
            dg = bpy.context.evaluated_depsgraph_get()
            bvh = world_bvh(centro, dg)
            ev = eyes.evaluated_get(dg)
            me = ev.to_mesh()
            mw = ev.matrix_world
            ys = [(mw @ v.co).y for v in me.vertices]
            ymin = min(ys)
            for v in me.vertices:
                p = mw @ v.co
                if p.y > ymin + 1e-4:
                    continue                      # so a tampa frontal
                hit = bvh.ray_cast(Vector((p.x, p.y - 1.0, p.z)), Vector((0, 1, 0)))
                if hit[0] is None:
                    worst = max(worst, 9.0)
                    continue
                worst = max(worst, abs((hit[0].y - 0.006) - p.y))
            ev.to_mesh_clear()
    eyes.location = (0, 0, 0)
    return round(worst, 5)


report2 = {"eye_test_closed_f1": eye_range_test(1, eyes["look_range_closed"].to_dict()),
           "eye_test_open_f30": eye_range_test(30, eyes["look_range_open"].to_dict())}

# ---- Open -> NLA (uma trilha "Open" por ID animado)
open_ids = [centro, esq, dire, anchor, chk, centro.data.shape_keys, esq.data.shape_keys,
            dire.data.shape_keys, mat_l.node_tree, mat_r.node_tree]


def to_nla(idb, clip):
    ad = idb.animation_data
    act = ad.action
    tr = ad.nla_tracks.new()
    tr.name = clip
    st = tr.strips.new(clip, int(act.frame_range[0]), act)
    if getattr(st, "action_slot", None) is None and act.slots:
        st.action_slot = act.slots[0]
    ad.action = None
    return st


slot_ok = []
for idb in open_ids:
    if idb.animation_data and idb.animation_data.action:
        st = to_nla(idb, "Open")
        slot_ok.append(st.action_slot is not None)
report2["open_strips"] = len(slot_ok)
report2["open_slots_ok"] = all(slot_ok)

# ---- Idle_Float (loop de 48 frames = 2 s): bob em Z + leve balanco em Y, so no no Mascote_Float
A_Z, A_R = 0.07, math.radians(2.0)
key_obj(flt, "location", 2, [(1, 0.0), (13, A_Z), (25, 0.0), (37, -A_Z), (49, 0.0)])
key_obj(flt, "rotation_euler", 1, [(1, 0.0), (13, -A_R), (25, 0.0), (37, A_R), (49, 0.0)])
for fc in fcurves_of(flt):
    for kp in fc.keyframe_points:
        kp.handle_left_type = kp.handle_right_type = "AUTO"
    fc.modifiers.new("CYCLES")
    fc.update()
to_nla(flt, "Idle_Float")

# ---- Spin_360 (26 frames ~ 1.1 s): antecipacao, giro completo com leve overshoot, assenta em 2*pi
key_obj(spn, "rotation_euler", 2, [(1, 0.0), (6, -0.20), (20, 2 * math.pi + 0.12), (26, 2 * math.pi)])
to_nla(spn, "Spin_360")

# ---- verificacoes pos-NLA
for ob_ in (centro, esq, dire):
    pass
scene.frame_set(1)
dg = bpy.context.evaluated_depsgraph_get()
d1 = {ob.name: [round(x, 4) for x in (lambda b: [b[1][i] - b[0][i] for i in range(3)])(bbox(eval_world_verts(ob, dg)))]
      for ob in (centro, esq, dire)}
scene.frame_set(30)
dg = bpy.context.evaluated_depsgraph_get()
# Float em f30 desloca tudo em Z; mede dimensoes (invariantes) e nao posicoes
d30 = {ob.name: [round(x, 4) for x in (lambda b: [b[1][i] - b[0][i] for i in range(3)])(bbox(eval_world_verts(ob, dg)))]
       for ob in (centro, esq, dire)}
report2["dims_f1"], report2["dims_f30"] = d1, d30

# overlaps do Open com Idle+Spin em paralelo (movimento rigido -> deve continuar 0)
ovl = 0
for f in range(1, 31):
    for s_ in (0.0, 0.5):
        scene.frame_set(f, subframe=s_)
        dg = bpy.context.evaluated_depsgraph_get()
        objs = blocks + list(extras)
        bv = {o: world_bvh(o, dg) for o in objs}
        for i in range(len(objs)):
            for j in range(i + 1, len(objs)):
                A, B = objs[i], objs[j]
                if extras.get(A) is B or extras.get(B) is A:
                    continue
                if bv[A].overlap(bv[B]):
                    ovl += 1
report2["overlaps_with_idle_and_spin"] = ovl

scene.frame_set(26)
report2["spin_z_f26_over_2pi"] = round(spn.matrix_basis.to_euler().z / (2 * math.pi), 4) if False else round(
    spn.evaluated_get(bpy.context.evaluated_depsgraph_get()).rotation_euler.z / (2 * math.pi), 4)
zs = []
for f in range(1, 50):
    scene.frame_set(f)
    zs.append(flt.evaluated_get(bpy.context.evaluated_depsgraph_get()).location.z)
report2["float_z_range"] = [round(min(zs), 4), round(max(zs), 4)]
report2["float_loop_closes"] = abs(zs[0] - zs[-1]) < 1e-6

# ---- renders de conferencia dos olhos nos extremos (opcional)
if "--render" in sys.argv:
    scene.cycles.samples = 24
    r.resolution_x, r.resolution_y = 960, 540
    for trk in flt.animation_data.nla_tracks:
        trk.mute = True
    for trk in spn.animation_data.nla_tracks:
        trk.mute = True
    for fr, rng, tag in ((1, (0.05, 0.25), "closed"), (30, (0.33, 0.035), "open")):
        scene.frame_set(fr)
        eyes.location = (rng[0], 0, rng[1])
        scene.camera = camf
        r.filepath = f"{OUT}/eyes_{tag}_extremo.png"
        bpy.ops.render.render(write_still=True)
    eyes.location = (0, 0, 0)
    for trk in list(flt.animation_data.nla_tracks) + list(spn.animation_data.nla_tracks):
        trk.mute = False
    scene.camera = cam34

# ---- salvar + exportar
scene.frame_set(1)
bpy.ops.wm.save_as_mainfile(filepath=f"{OUT}/agilebox_mascote_anim.blend")
glb = f"{OUT}/agilebox_mascote.glb"
# so na copia exportada: desloca 1 frame para que os clipes do GLB comecem em t=0 (o .blend ja foi salvo em 1-30)
for _id in open_ids + [flt, spn]:
    if _id.animation_data:
        for _t in _id.animation_data.nla_tracks:
            for _s in _t.strips:
                _s.frame_start_ui = _s.frame_start_ui - 1
bpy.ops.object.select_all(action="DESELECT")
for _o in (root, flt, spn, centro, esq, dire, anchor, eyes, chk):
    _o.select_set(True)
try:
    bpy.ops.export_scene.gltf(filepath=glb, export_format="GLB", export_animations=True,
                              export_animation_mode="NLA_TRACKS", export_force_sampling=True,
                              export_extras=True, export_apply=False, export_cameras=False,
                              export_lights=False, export_yup=True, use_selection=True)
    d = open(glb, "rb").read()
    jl = struct.unpack("<I", d[12:16])[0]
    g = json.loads(d[20:20 + jl])
    anims = []
    for an in g.get("animations", []):
        dur = 0.0
        for smp in an["samplers"]:
            mx = g["accessors"][smp["input"]].get("max", [0])[0]
            dur = max(dur, mx)
        anims.append({"name": an["name"], "channels": len(an["channels"]), "seconds": round(dur, 3)})
    report2["glb"] = {"bytes": len(d), "animations": anims,
                      "nodes": [n["name"] for n in g["nodes"]],
                      "morph_meshes": [m["name"] for m in g["meshes"] if any("targets" in p for p in m["primitives"])],
                      "extras_nodes": [n["name"] for n in g["nodes"] if "extras" in n]}
except Exception as e:  # noqa
    report2["glb_error"] = repr(e)

print("REPORT2", json.dumps(report2, indent=1))
