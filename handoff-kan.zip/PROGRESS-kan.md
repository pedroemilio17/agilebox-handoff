## Kan · assistente guiado e mascote 3D (docs/KAN.md, ADR 0005)

> Cole esta seção no fim de `PROGRESS.md`. Antes de qualquer passo: ler `docs/KAN.md`, `docs/decisoes/0005-kan-assistente-guiado.md` e `design/kan/README.md`. Cada passo: explicar o plano e esperar o OK do Pedro (CLAUDE.md); `pnpm check` antes de marcar.

- [ ] Kan.1 Roteiro puro no core
  - Arquivos: `packages/core/src/modules/kan/{script.ts,kan-flow.ts,index.ts}` e testes ao lado; exportar em `packages/core/src/index.ts`.
  - Escopo: nós (`id`, `text`, `options[{label,next,action?}]`), passos derivados de `manifest.ts`/`guide.ts` (sem duplicar texto), `nextNode(state, choice)` pura. Ações possíveis: `openModule`, `showHow`, `skip`, `later`, `complete`. Portar a máquina de nós de `design/kan/canvas/Main.dc.html` (welcome/list/step/how/go/done/skip/later/complete/doubts/ans).
  - Pronto: testes cobrem caminho feliz dos 6 passos, pular, depois, concluir tudo, dúvidas; sem I/O nem relógio; `pnpm check` passa.

- [ ] Kan.2 Textos e preferências
  - Arquivos: `apps/desktop/src/renderer/panel/kan/kan-copy.ts`; `apps/desktop/src/main/preferences/kan.ts` (padrão de `appearance.ts`: `kan.json` em userData, `corner`, `enabled`) + IPC mínimo e teste.
  - Pronto: ler/gravar com valor padrão e arquivo corrompido tratado; fronteiras de camadas respeitadas.

- [ ] Kan.3 Chat aberto (sem mascote)
  - Arquivos: `renderer/panel/kan/{KanChat.tsx,KanOptions.tsx,use-kan.ts}`.
  - Escopo: abas Guia/Primeiros passos/Dúvidas, mensagens de baixo para cima, grade de opções, foco e `aria-live`, progresso via `guideProgress`, "Abrir módulo" navega ao módulo certo. Comparar com `design/kan/canvas/Painel_Aberto.dc.html`.
  - Pronto: testes de Testing Library (percorrer um passo só com teclado); `prefers-reduced-motion` respeitado.

- [ ] Kan.4 Dock fechado com pôster
  - Arquivos: `renderer/panel/kan/{KanDock.tsx,KanMascotPoster.tsx}`; copiar `design/kan/assets/kan_fechado.png` para `renderer/assets/`.
  - Escopo: canto do painel, balão "Próximo: …", clique abre o chat. Ainda sem 3D. Ver `Painel_Fechado.dc.html`.
  - Pronto: teste de abrir/fechar; canto vem da preferência.

- [ ] Kan.5 [manual] DEPENDÊNCIA: `three`
  - Pedro roda `pnpm --filter @agilebox/desktop add three` (e `-D @types/three`). Conferir se o `typescript-eslint` e o build electron-vite seguem passando (ADR 0003).

- [ ] Kan.6 Mascote 3D
  - Arquivos: `renderer/panel/kan/KanMascot.tsx` (import dinâmico de `three`), `kan-mascot-engine.ts` (lógica pura testável: tabela de tween, limites dos olhos, fila de clipes), `renderer/assets/agilebox_mascote.glb`.
  - Escopo: contrato de `docs/KAN.md` §4; clipes Open (e reverso), Idle_Float, Spin_360; olhos seguem o ponteiro e, depois, o foco/seleção; dpr ≤ 1,5, 30 fps, pausa oculto; dispose no unmount; fallback ao pôster em reduced-motion ou sem WebGL. Referência: `design/kan/src/kan3d.reference.js`.
  - Pronto: testes do engine (tween, limites, normalização); build empacota o GLB; conferência visual manual no Windows e no Fedora.

- [ ] Kan.7 Ligar Open ↔ chat
  - Escopo: abrir chat toca `Open`; fechar toca reverso; Spin_360 ao concluir passo. Sem travar a UI se o 3D falhar.
  - Pronto: fluxo completo com e sem WebGL.

- [ ] Kan.8 [manual] DECIDIR: mascote em janela própria? (docs/KAN.md §6.1)
  - Opções: (a) ficar dentro do painel; (b) janela transparente, sempre no topo, arrastável (muda `tray-window`/`window-manager`; cuidado com X11/transparência e foco). Pedro escolhe; só então detalhar passos.

- [ ] Kan.9 Remover o guia antigo
  - Pré-requisito: Pedro aprovou o Kan e o mapeamento das intensidades do guia.
  - Escopo: remover componentes, hooks e copy listados em `docs/KAN.md` §3; ajustar testes; sem deixar código morto.
  - Pronto: `pnpm check` passa; nenhuma referência restante a `GuideDock`/`WelcomeDialog`/`ModuleHelpButton`.

- [ ] PARADA Kan: Pedro percorre o chat do início ao fim, com e sem WebGL, e confere o mascote no Windows e no Fedora.
