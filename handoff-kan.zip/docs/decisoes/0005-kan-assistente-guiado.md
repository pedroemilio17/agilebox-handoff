# 0005 · Kan: guia vira chat guiado por opções, com mascote 3D em three.js

- **Data**: 2026-11-21
- **Estado**: proposto (aguardando confirmação do Pedro). Renumerar se já existir 0005.

## Contexto

O guia atual são cartões, diálogo de boas-vindas e botões de ajuda espalhados pelos módulos. O Pedro quer tudo isso como módulos de um assistente ("Kan") em chat guiado, mensagem por mensagem, só com opções. Há um mascote 3D pronto (GLB, 3 clipes). IA embarcada continua fora do MVP.

## Decisão

1. Roteiro determinístico em `packages/core` (dado + função pura), passos vindos do manifesto existente.
2. UI em `apps/desktop/src/renderer/panel/kan/`; o guia antigo é removido só no fim.
3. Mascote: **three.js** com GLB como asset, carregado por import dinâmico; pôster PNG como fallback. (Alternativas descartadas: `<model-viewer>`, que falhou no sandbox do canvas e pesa mais; vídeo/Lottie, que não reage ao olhar nem ao arraste.)
4. Janela própria para o mascote **não** faz parte desta decisão: fica como passo separado com confirmação.

## Consequências

- Nova dependência de runtime no desktop: `three` (~0,6 MB minificado, só carrega quando o mascote aparece). Pedro roda o `pnpm add`.
- O Kan não usa texto livre nem IA; mudar isso exige nova decisão.
- Preferências do guia precisam de mapeamento antes da remoção.

## Quando revisitar

Quando o Kan passar a se mover pela tela (janela própria) ou ganhar texto livre/IA.
