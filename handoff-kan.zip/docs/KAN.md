# Kan · assistente guiado e mascote 3D (especificação)

Nome provisório. Estado: **desenhado e com assets prontos; nada implementado no app.** Referências visuais em `design/kan/` (ver README de lá).

## 1. O que é

Um chat guiado, programado, que substitui o guia atual (primeiros passos em cartões/quadros, dúvidas, ajuda por módulo). Três módulos do Kan:

1. **Guia** — conduz o fluxo geral e responde "o que faço agora?".
2. **Primeiros passos** — os mesmos passos do manifesto (`packages/core/src/modules/manifest.ts`), contados um por vez, mensagem por mensagem.
3. **Dúvidas** — perguntas frequentes em lista de opções.

Regras de interação:
- **Só opções.** Sem campo de texto livre; cada mensagem do Kan termina em 2–4 botões. Nada de IA (CLAUDE.md: IA embarcada está fora do MVP). É um roteiro determinístico.
- **Uma mensagem por vez**, de baixo para cima (a mais nova embaixo), curtas, em pt-BR.
- Cada passo: título → "por quê" (`why`) → ações: **Abrir o módulo**, **Como faço?**, **Pular**, **Depois**. O passo conclui sozinho quando o evento do manifesto (`doneWhen`) acontece.
- **Futuro (fora desta entrega):** o Kan se move na tela até o ponto onde o usuário deve clicar. Hoje só *abre* o módulo certo.

## 2. Superfícies

- **Fechado:** mascote 3D pequeno (≈150×150) no canto escolhido, com balão "Próximo: …". Clicar abre o chat.
- **Aberto:** o bloco "abre" (clipe `Open`) e vira o painel de chat cobrindo a janela de baixo para cima; abas Guia / Primeiros passos / Dúvidas; grade de opções.
- **Arrastar** (fase posterior): segurar e soltar em um dos cantos; persiste a escolha.
- Estados e roteiro completos: `design/kan/canvas/Main.dc.html` (máquina de nós), `Estados.dc.html`, `Roteiro.dc.html`, `Painel_Fechado/Aberto.dc.html`.

## 3. Arquitetura proposta (segue PLANO 3.1)

| Camada | O que entra |
| --- | --- |
| `packages/core/src/modules/kan/` | Roteiro como **dado puro** (nós: `id`, `text`, `options[{label,next,action?}]`) e `kan-flow.ts` (função pura `nextNode(state, choice)`). Passos vêm de `manifest.ts` + `guide.ts` (`buildGuideTrail`, `guideProgress`): **fonte única, não duplicar** o texto dos passos. Sem I/O, sem relógio. |
| `packages/application` / `contract` | Reaproveitar o progresso do guia derivado de eventos. Só criar caso de uso novo se faltar algo (ex.: "pular"/"depois" persistidos). Perguntar ao Pedro antes. |
| `apps/desktop/src/main` | Preferências do Kan (`kan.json` em userData, mesmo padrão de `appearance.json`): canto, ligado/desligado. IPC mínimo. |
| `apps/desktop/src/renderer/panel/kan/` | `KanDock` (fechado), `KanChat` (aberto), `KanMascot` (wrapper React do three.js, **import dinâmico**), `kan-copy.ts` (textos). |
| `packages/ui` | Só se surgir componente reutilizável (bolha de mensagem, grade de opções). |

Remoção (último passo, depois do Kan funcionando): `GuideDock`, `GuideCard`, `WelcomeDialog`, `ModuleHelpButton`, `ModuleEmptyState` de guia, `guide-copy.ts`, `welcome-copy.ts`, `module-help-copy.ts`, hooks `use-guide`, `use-dismiss-guide-card`, `use-resolve-guide-welcome`. Mapear as **intensidades do guia** (firstStepsCard open/collapsed/hidden, emptyState full/short, firstTimeHints, explainJargon) para o Kan antes de apagar — não perder a preferência existente sem avisar.

## 4. Contrato do modelo 3D (`design/kan/assets/agilebox_mascote.glb`)

Y-up no glTF (frente = +Z). Hierarquia e **quem controla cada nó**:

```
Mascote_Root     ← app: posição/arrasto
└ Mascote_Float  ← clipe Idle_Float (loop; ±0,07 u em Z, ±2°)
  └ Mascote_Spin ← clipe Spin_360 (uma volta, 1,042 s)
    ├ Bloco_Centro
    │ └ Olhos_Ancora ← clipe Open
    │   └ Olhos_LED  ← app: olhar (offset local)
    ├ Bloco_Esquerda   (vira o painel de vidro)
    └ Bloco_Direita
      └ Icone_Check
```

- Clipes: `Open` 1,208 s (fechado→aberto; tocar com `timeScale = -1` para fechar), `Idle_Float` 2,0 s, `Spin_360` 1,042 s. Todos começam em t=0.
- **Material não anima no glTF**: tween em código (da `Open`, 24 fps): Esquerda `#1d1c23 r0.58 → #17161c r0.28`, opacidade 1 → 0,78 em 7/24–25/24 s; Direita `#1d1c23 r0.58 → #c8f03c r0.42` em 9/24–27/24 s. LED emissivo `#f2f0f6` força 2,4.
- Olhos: limite em X ±0,05 (fechado) → ±0,33 (aberto); em Z cima 0,25 → 0,035, baixo 0,30 → 0,035. Entrada normalizada −1…1, suavizar com `1 − exp(−dt·8)`.
- Os pesos de morph (Dim_X/Y/Z, Recesso) estão amostrados por frame no GLB; **não regenerar sem rodar `fix_glb_morphs.py`.**

## 5. Performance e acessibilidade (inegociáveis)

- `three` só entra via `import()` dinâmico quando o mascote aparece; ~170 KB de GLB como asset do renderer (sem base64 embutido).
- Canvas pequeno, `dpr ≤ 1,5`, 30 fps, **pausar** quando oculto (`IntersectionObserver` + `document.hidden`), iluminação leve (RoomEnvironment + 2 luzes), descartar renderer no unmount.
- `prefers-reduced-motion` ou falha de WebGL → mostrar o pôster PNG (`kan_fechado.png`), sem girar/flutuar; o chat continua funcionando por inteiro.
- Chat acessível sem o mascote: botões reais, foco gerenciado, `aria-live` na mensagem nova, alvos ≥ 44 px (como o resto do app).
- Janela alvo: Windows e Fedora/X11 (CLAUDE.md). Transparência real só vale em janela própria; ver decisão aberta.

## 6. Decisões em aberto (perguntar ao Pedro, não decidir)

1. **Mascote dentro da janela do painel ou em janela própria** (transparente, sempre no topo, para ficar na frente de outras telas e ser arrastado)? Recomendação: começar **dentro da janela** (passos Kan.1–Kan.7) e tratar a janela própria como passo separado (Kan.8), pois muda `tray-window`/`window-manager`, glass e foco, e no Linux exige cuidado com transparência em X11.
2. "Pular"/"Depois" precisam persistir entre sessões? (hoje o guia deriva tudo de eventos).
3. Intensidades do guia: viram preferência do Kan ou somem?
4. Nome final do assistente (hoje provisório "Kan").
5. Textos finais das Dúvidas (as 4 do protótipo são rascunho).
