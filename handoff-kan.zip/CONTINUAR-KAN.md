# Continuar: Kan no Claude Code

## Como aplicar este pacote
1. Na raiz do repositório (branch nova, ex.: `claude/kan`), copie o conteúdo desta pasta mantendo os caminhos: `docs/KAN.md`, `docs/decisoes/0005-…md`, `design/kan/…`.
2. Cole `PROGRESS-kan.md` no fim de `PROGRESS.md`.
3. Confira o estado atual: `git log -3`, `docs/CONTINUAR-REDESIGN-v2.md` (o redesign v2 está incompleto; não misturar).
4. `pnpm install && pnpm check` para ter a linha de base.

## Prompt para colar no Claude Code
> Leia `CLAUDE.md`, `docs/KAN.md`, `docs/decisoes/0005-kan-assistente-guiado.md`, `design/kan/README.md` e a seção "Kan" do `PROGRESS.md`. Explique em poucas linhas o que fará no **Kan.1** e espere meu OK. Não decida sozinho as "Decisões em aberto" do `docs/KAN.md` §6; pergunte. Siga as fronteiras do PLANO 3.1 e rode `pnpm check` antes de concluir o passo.

## Pontos de atenção
- Os 6 passos do protótipo espelham o manifesto; **o manifesto do repo manda**. Se divergirem, ajuste o roteiro, não o manifesto.
- Não regenerar o GLB sem `design/kan/tools/fix_glb_morphs.py`.
- `design/kan/canvas/*.dc.html` são só referência visual.
- O canvas de design continua editável online; o que está aqui é um retrato de 2026-11-21.
